'use client'


import { useCallback, useState } from 'react'
import { useRouter } from 'next/navigation'

const BOTAO: React.CSSProperties = {
  appearance: 'none',
  border: '1px solid var(--border-subtle, rgba(255,255,255,0.12))',
  background: 'transparent',
  color: 'var(--text-secondary)',
  borderRadius: 10,
  padding: '7px 12px',
  fontSize: 13,
  fontWeight: 500,
  cursor: 'pointer',
  lineHeight: 1.2,
}


export const TEXTO_ANTES_DE_ENVIAR = [
  'Isto envia para o repositório novo, no GitHub, tudo o que está guardado neste servidor: as memórias em uso, as arquivadas, as habilidades e o histórico completo de alterações, inclusive o que já tinha sido apagado ou corrigido antes. Quem tem acesso ao repositório novo passa a ver tudo isso.',
  'Se você criou o repositório de novo para tirar algum conteúdo do ar, não envie: esse conteúdo volta.',
  'Nada do que já está no repositório novo é apagado. Se um arquivo existir nos dois lugares com o mesmo nome, fica valendo o daqui.',
] as const

export function EnviarMemorias() {
  const router = useRouter()
  const [confirmando, setConfirmando] = useState(false)
  const [enviando, setEnviando] = useState(false)
  const [resultado, setResultado] = useState<{ ok: boolean; texto: string } | null>(null)

  const enviar = useCallback(async () => {
    setEnviando(true)
    setResultado(null)
    try {
      const r = await fetch('/api/cerebro/enviar-memorias', { method: 'POST' })
      const corpo = (await r.json().catch(() => ({}))) as { mensagem?: string; error?: string }
      if (r.ok) {
        setResultado({ ok: true, texto: corpo.mensagem ?? 'Pronto.' })
        setConfirmando(false)
        
        setTimeout(() => router.refresh(), 6000)
      } else {
        setResultado({ ok: false, texto: corpo.error ?? 'Não consegui enviar agora. Nada foi alterado.' })
      }
    } catch {
      setResultado({ ok: false, texto: 'Não consegui falar com o servidor. Nada foi alterado.' })
    } finally {
      setEnviando(false)
    }
  }, [router])

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8, margin: '12px 0 4px', maxWidth: 640 }}>
      {confirmando ? (
        <>
          {TEXTO_ANTES_DE_ENVIAR.map((paragrafo, i) => (
            <p key={i} style={{ margin: 0, fontSize: 13, lineHeight: 1.5, color: i === 1 ? 'var(--text-primary)' : 'var(--text-secondary)', fontWeight: i === 1 ? 600 : 400 }}>{paragrafo}</p>
          ))}
          <div style={{ display: 'flex', gap: 8 }}>
            <button type="button" style={BOTAO} disabled={enviando} onClick={() => setConfirmando(false)}>Cancelar</button>
            <button type="button" style={{ ...BOTAO, color: 'var(--text-primary)' }} disabled={enviando} onClick={() => { void enviar() }}>
              {enviando ? 'Enviando…' : 'Enviar agora'}
            </button>
          </div>
        </>
      ) : (
        <div>
          <button type="button" style={{ ...BOTAO, color: 'var(--text-primary)' }} disabled={resultado?.ok === true} onClick={() => { setResultado(null); setConfirmando(true) }}>
            Enviar as memórias para o repositório novo
          </button>
        </div>
      )}
      {resultado && (
        <p role="status" style={{ margin: 0, fontSize: 13, lineHeight: 1.5, color: resultado.ok ? 'var(--text-secondary)' : 'var(--danger, #ff6b6b)' }}>
          {resultado.texto}
        </p>
      )}
    </div>
  )
}
