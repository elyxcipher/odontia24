
import { cookies } from 'next/headers'
import { requireDonoApi } from '@/server/auth/apiAuth'
import { withCloneLock } from '@/server/brain/cloneLock'
import { cloneDir } from '@/server/brain/skillsPaths'
import { enviarMemoriasGuardadas, COPY_DO_ENVIO } from '@/server/brain/enviarMemorias'
import { esquecerVeredito } from '@/server/brain/travaDoClone'
import { invalidateBrainCache } from '@/server/brain/runtime'
import { veredictosAZerar } from '@/lib/config/desconfiancaDasChaves'
import { setSetting } from '@/data/settings'
import { mesmaOrigem } from '@/server/auth/mesmaOrigem'
import { portaoSondaCerebro } from '@/server/heartbeat/cadencia'


async function esquecerOEstadoDeAntes(dir: string): Promise<void> {
  esquecerVeredito(dir)
  invalidateBrainCache()
  portaoSondaCerebro.esquecer()
  try {
    await Promise.all(veredictosAZerar(['github_token']).map((chave) => setSetting(chave, '')))
  } catch {
    
  }
}

export async function POST(request: Request) {
  
  if (!mesmaOrigem(request)) return Response.json({ error: 'Origem não permitida.' }, { status: 403 })
  const auth = await requireDonoApi(await cookies())
  if (auth instanceof Response) return auth

  const dir = cloneDir()
  let r: Awaited<ReturnType<typeof enviarMemoriasGuardadas>>
  try {
    
    r = await withCloneLock(() => enviarMemoriasGuardadas(dir, process.env.BRAIN_BRANCH ?? 'main', 30_000))
  } catch {
    
    
    await esquecerOEstadoDeAntes(dir)
    return Response.json({ error: 'O Cérebro demorou a responder e eu não consegui confirmar o envio. Recarregue esta tela em um minuto: se o aviso continuar, envie de novo.' }, { status: 503 })
  }

  if (!r.ok) {
    
    if (r.motivo === 'nada_a_enviar' || r.motivo === 'sem_confirmacao') await esquecerOEstadoDeAntes(dir)
    const status = r.motivo === 'nada_a_enviar' ? 409 : r.motivo === 'recusado' ? 502 : 503
    return Response.json({ error: COPY_DO_ENVIO[r.motivo] }, { status })
  }

  await esquecerOEstadoDeAntes(dir)
  return Response.json({ ok: true, mensagem: COPY_DO_ENVIO[r.como] })
}
